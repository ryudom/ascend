// Shared Supabase auth (email OTP) — same project/pattern as Ascend, so one
// account works across both apps.
export const SB_URL = "https://dsucgqlfpvmbwdbmwdfg.supabase.co";
export const SB_KEY = "sb_publishable_c52lP93z7puu5aVVfG7zcQ_lqQLniX4";

export const TOKEN_KEY = "divineArts:cloudToken";
export const REFRESH_KEY = "divineArts:cloudRefresh";

export async function sendOTP(email) {
  try {
    const r = await fetch(`${SB_URL}/auth/v1/otp`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email, create_user: true }),
    });
    return { ok: r.ok, error: r.ok ? null : (await r.json()).message };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function verifyOTP(email, token) {
  try {
    const r = await fetch(`${SB_URL}/auth/v1/verify`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ type: "email", token, email }),
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.message || d.error_description || "Invalid code" };
    return { ok: true, access_token: d.access_token, refresh_token: d.refresh_token, user: d.user };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function getUser(token) {
  if (!token) return null;
  try {
    const r = await fetch(`${SB_URL}/auth/v1/user`, {
      headers: { Authorization: `Bearer ${token}`, apikey: SB_KEY },
    });
    return r.ok ? await r.json() : null;
  } catch {
    return null;
  }
}

export async function refreshToken(refresh_token) {
  if (!refresh_token) return null;
  try {
    const r = await fetch(`${SB_URL}/auth/v1/token?grant_type=refresh_token`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ refresh_token }),
    });
    if (!r.ok) return null;
    const d = await r.json();
    return { access_token: d.access_token, refresh_token: d.refresh_token, user: d.user };
  } catch {
    return null;
  }
}

export function saveSession(access_token, refresh_token) {
  try {
    localStorage.setItem(TOKEN_KEY, access_token);
    if (refresh_token) localStorage.setItem(REFRESH_KEY, refresh_token);
  } catch {}
}

export function clearSession() {
  try {
    localStorage.removeItem(TOKEN_KEY);
    localStorage.removeItem(REFRESH_KEY);
  } catch {}
}

export async function fetchEntitlements(accessToken) {
  try {
    const r = await fetch(`${SB_URL}/rest/v1/entitlements?select=product_id,product_name,granted_at`, {
      headers: { apikey: SB_KEY, Authorization: `Bearer ${accessToken}` },
    });
    if (!r.ok) return { ok: false, error: "Couldn't load purchases." };
    const rows = await r.json();
    return { ok: true, productIds: rows.map((row) => row.product_id) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function getLibraryFile(accessToken, productId) {
  try {
    const r = await fetch(`${SB_URL}/functions/v1/get-library-file`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify({ product_id: productId }),
    });
    const d = await r.json();
    if (!r.ok || !d.url) return { ok: false, error: d.error || "Couldn't open file." };
    return { ok: true, url: d.url };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function unlockAnchored(email, password, productId, productName) {
  try {
    const r = await fetch(`${SB_URL}/functions/v1/unlock-anchored`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email, password, product_id: productId || "anchored", product_name: productName }),
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.error || "Couldn't create your account." };
    return { ok: true, isNewUser: !!d.isNewUser };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function syncSystemeContact(email, subscribed, source) {
  try {
    await fetch(`${SB_URL}/functions/v1/sync-systeme-contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email, subscribed, source }),
    });
  } catch (e) {
    // Non-fatal — never block signup/unlock on the email sync.
  }
}

export async function removeSystemeContact(email) {
  try {
    await fetch(`${SB_URL}/functions/v1/remove-systeme-contact`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email }),
    });
  } catch (e) {
    // Non-fatal — account deletion should proceed either way.
  }
}

export async function logPracticeSession(accessToken, { practiceType, durationSeconds, startedAt, meta }) {
  try {
    await fetch(`${SB_URL}/rest/v1/practice_sessions`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY, Authorization: `Bearer ${accessToken}`, Prefer: "return=minimal" },
      body: JSON.stringify({
        practice_type: practiceType || "sitting", duration_seconds: durationSeconds,
        started_at: startedAt || new Date().toISOString(), source_app: "divine_arts", meta: meta || {},
      }),
    });
  } catch (e) {
    // Non-fatal — never block the practice UI on this.
  }
}

export async function countPracticeSessions(accessToken) {
  try {
    const r = await fetch(`${SB_URL}/rest/v1/practice_sessions?select=id`, {
      headers: { apikey: SB_KEY, Authorization: `Bearer ${accessToken}`, Prefer: "count=exact" },
    });
    if (!r.ok) return { ok: false, count: 0 };
    const range = r.headers.get("content-range"); // "0-9/23"
    const total = range ? parseInt(range.split("/")[1], 10) : (await r.json()).length;
    return { ok: true, count: total || 0 };
  } catch (e) {
    return { ok: false, count: 0 };
  }
}

export function loadSession() {
  try {
    return { token: localStorage.getItem(TOKEN_KEY), refresh: localStorage.getItem(REFRESH_KEY) };
  } catch {
    return { token: null, refresh: null };
  }
}

export async function updateUser(accessToken, updates) {  try {
    const r = await fetch(`${SB_URL}/auth/v1/user`, {
      method: "PUT",
      headers: { "Content-Type": "application/json", apikey: SB_KEY, Authorization: `Bearer ${accessToken}` },
      body: JSON.stringify(updates),
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.message || d.error_description || "Update failed" };
    return { ok: true, user: d };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function requestPasswordReset(email, redirectTo) {
  try {
    const r = await fetch(`${SB_URL}/auth/v1/recover`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email, redirect_to: redirectTo || window.location.href }),
    });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) return { ok: false, error: d.message || d.error_description || "Couldn't send reset email." };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function deleteAccount(accessToken) {
  try {
    const r = await fetch(`${SB_URL}/functions/v1/delete-account`, {
      method: "POST",
      headers: { apikey: SB_KEY, Authorization: `Bearer ${accessToken}` },
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.error || "Delete failed" };
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function signUpPassword(email, password, data) {
  try {
    const body = { email, password };
    if (data) body.data = data;
    const r = await fetch(`${SB_URL}/auth/v1/signup`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify(body),
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.message || d.error_description || "Sign up failed" };
    if (!d.access_token) return { ok: true, needsConfirm: true }; // email confirmation required
    return { ok: true, access_token: d.access_token, refresh_token: d.refresh_token, user: d.user };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

export async function signInPassword(email, password) {
  try {
    const r = await fetch(`${SB_URL}/auth/v1/token?grant_type=password`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: SB_KEY },
      body: JSON.stringify({ email, password }),
    });
    const d = await r.json();
    if (!r.ok) return { ok: false, error: d.message || d.error_description || "Wrong email or password" };
    return { ok: true, access_token: d.access_token, refresh_token: d.refresh_token, user: d.user };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

// Redirects the browser to Google via Supabase's OAuth flow. Requires the
// Google provider to be enabled (Client ID/secret) in the Supabase dashboard
// under Authentication > Providers first — that step can't be done from code.
export function signInWithGoogle(redirectTo) {
  const url = `${SB_URL}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectTo || window.location.href)}`;
  window.location.href = url;
}

// OAuth redirects back with tokens in the URL hash (#access_token=...&refresh_token=...).
// Call once on page load; returns the session if present and cleans the hash.
export function consumeOAuthHash() {
  if (!location.hash || !location.hash.includes("access_token")) return null;
  const params = new URLSearchParams(location.hash.slice(1));
  const access_token = params.get("access_token");
  const refresh_token = params.get("refresh_token");
  if (!access_token) return null;
  history.replaceState(null, "", location.pathname + location.search);
  return { access_token, refresh_token };
}
