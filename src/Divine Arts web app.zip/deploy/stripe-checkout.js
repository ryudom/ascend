// Client-side helper: asks a Supabase Edge Function to create a Stripe embedded
// Checkout Session (secret key never touches the browser) and returns its client_secret
// for mounting inline via Stripe.js's Embedded Checkout — no page redirect, no
// hosted-page anti-framing restrictions, works inside any preview.
const FN_URL = "https://dsucgqlfpvmbwdbmwdfg.supabase.co/functions/v1/create-checkout-session";
const SB_KEY = "sb_publishable_c52lP93z7puu5aVVfG7zcQ_lqQLniX4";
// Publishable key must be from the SAME Stripe mode (test/live) as the secret key
// currently set on the create-checkout-session function's STRIPE_SECRET_KEY.
export const STRIPE_PUBLISHABLE_KEY = "pk_live_51Tuy5rRX8T087Ss8f1ybdE1hoIJwlk93In7ULFqZgqAvZmTHHc1O5oO5w2bNiGjJZZZpyNejbpWGxRYcqzWUJlh800YtWK2BgG";

export async function startCheckout(productId, accessToken, opts = {}) {
  if (!accessToken) return { ok: false, error: "Not logged in." };
  try {
    const r = await fetch(FN_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${accessToken}`, apikey: SB_KEY },
      body: JSON.stringify({
        product_id: productId,
        success_url: opts.successUrl || `${location.origin}${location.pathname}?checkout=success`,
      }),
    });
    const d = await r.json();
    if (!r.ok || !d.clientSecret) return { ok: false, error: d.error || "Checkout failed to start." };
    return { ok: true, clientSecret: d.clientSecret };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

let stripeInstance = null;
export async function getStripe() {
  if (stripeInstance) return stripeInstance;
  if (!window.Stripe) {
    await new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://js.stripe.com/v3/";
      s.onload = resolve;
      s.onerror = reject;
      document.head.appendChild(s);
    });
  }
  stripeInstance = window.Stripe(STRIPE_PUBLISHABLE_KEY);
  return stripeInstance;
}

