# Divine Arts — Design System

A design system for **Divine Arts**, a contemplative training system for developing
embodied presence, created by **Dominique Arsenault**. Divine Arts teaches presence
through posture, breath, movement, and relaxation — rooted in contemplative
traditions, martial disciplines (tai chi, zhan zhuang, judo, jiu-jitsu), and lived
practice. It is not a meditation app, a stress-reduction program, or a belief system.

Tagline: **Presence. Clarity. Grounding.**
Positioning line: *A grounded path of embodiment and awareness.*

Divine Arts is part of the **Ascension Project** (ascensionproject.ca). Its offerings
("Works") — courses, manuals, and writings — are sold through Podia; the flagship is
**Foundations of Presence**, a six-week online course. A free lead magnet, *Get
Anchored* (guide + 5-minute practice), lives at divinearts.podia.com/anchored.

## Sources reviewed
- **Website:** https://www.divinearts.ca/ (Home, About, FAQ, Works, Path,
  Writings/"where you put your attention"). The live site is built on **Google Sites**
  with default styling — there is **no published design system or brand typeface**.
  The **brand mark** (a gold enso brush-circle on midnight navy) was provided separately
  by the client and is the anchor for the palette. This design system is therefore an
  *interpretation* grounded in the brand mark, content, tone, and subject matter, not a
  pixel recreation of an existing product.
- Course platform: divinearts.podia.com (Podia storefront — not directly inspected).
- Socials: Instagram @divine_arts_now, Facebook, email practice@divinearts.ca.

> No codebase or Figma file was provided. If one exists, re-attach it via the Import
> menu and this system can be aligned to the real source of truth.

## The brand's conceptual vocabulary
This vocabulary should inform copy, section names, and sample content across designs.
- **Five core capacities:** presence, clarity, root, attunement, will.
- **Four anchors:** posture, relaxation, breath, attention.
- **Three core practices:** sitting, standing, walking.
- **The lower dantien / hara / center of gravity:** the lower belly, ~2–3 finger-widths
  below the navel — the recurring physical + symbolic center of the whole practice.
- **Path pages:** Presence, Cultivation, Anchors, Skills.
- Framing motif: *"Different maps, same territory"* — traditions as maps, not doctrine.

---

## CONTENT FUNDAMENTALS

**Voice:** grounded, honest, measured, quietly authoritative. The narrator is an
engineer-turned-practitioner: methodical, precise, allergic to hype and spiritual
performance. Copy earns trust by *under*-claiming.

**Person:** First person singular for the founder's story ("My name is Dominique… I
grew up around forests"). Second person ("you") for teaching and instruction. "We" is
rare. The reader is addressed as a capable adult, never a customer to be converted.

**Sentence rhythm:** short, declarative sentences, often in deliberate fragments for
emphasis and pacing. Long explanatory sentences alternate with a one-line landing.
> "The shift is not dramatic. It doesn't announce itself."
> "Different maps, same territory."
> "That's it. That's the beginning of the whole thing."

**Casing:** Sentence case everywhere for body and most headings. Page titles are plain
("About", "FAQ", "Where you put your Attention"). The wordmark is set in **spaced
capitals**: `D I V I N E   A R T S`. Product names are Title Case ("Foundations of
Presence", "Get Anchored").

**Punctuation:** em-dashes — used liberally for grounded asides and definitions.
Occasional arrow glyphs in CTAs ("→ Learn more", "→ Enroll here").

**Concreteness:** always anchor abstractions in the body and the physical world.
"Two to three finger-widths below the navel," not "your energetic center." Physical,
verifiable, testable language over mystical vocabulary.

**What it avoids:** hype words (transform your life!, unlock, unleash), urgency/scarcity
tactics, exclamation marks, superlatives, and — critically — **no emoji, ever**. No
spiritual clichés presented uncritically; when traditional terms appear (qi, dantien,
Belt of Truth) they are defined plainly and cross-referenced across traditions.

**Claims discipline:** results are framed honestly and slowly ("This is cultivation, not
a quick fix… the way a tree grows"). Explicitly names what the practice is *not*.

**Sample copy to emulate:**
- Eyebrow / tagline: "Presence. Clarity. Grounding."
- Hero: "A grounded path of embodiment and awareness."
- CTA: "Explore the Path" · "Browse our Works" · "Get Anchored" · "→ Enroll here"
- Reassurance: "You don't need a technique to begin. You need a direction."

---

## VISUAL FOUNDATIONS

These foundations translate the brand mark (gold enso on midnight navy) and the site's
*content and feeling* — grounded, contemplative, unhurried, reading-first, quietly
luxe — into a coherent visual language. Confirm/refine with the founder.

**Overall feeling:** a well-made book or a quiet studio at dawn. Warm, natural,
uncrowded. Nothing shiny, gradient-heavy, or "tech." Space is a material.

**Color:** drawn straight from the brand mark. **Gold** (`--gold-500 #C9992E`) is the
single accent — the enso brushstroke. **Midnight navy** (`--navy-700 #0E1930`,
`--navy-900 #080F1E`) carries the dark, luxe brand surfaces — heroes, headers, footers.
For light reading surfaces, a warm **ivory** paper (`--paper #F6F3EA`) and a cool
**near-navy ink** (`--ink-900 #0C1424`) rather than pure white/black. Gold is the ONLY
chromatic accent; navy and ivory do the rest. On gold fills use dark navy text
(`--text-on-gold`); for gold *text/links* on ivory use the deeper `--gold-700`
(`--accent-ink`), since gold-500 is low-contrast at body size. Never neon, never
blue-purple gradients.

**Typography:** serif-forward and literary. **Spectral** carries display and long-form
reading (calm, sturdy, screen-ready); **Work Sans** handles UI labels, navigation,
buttons, and the signature wide-tracked eyebrow. Generous line-height (1.7 for body),
a comfortable ~640px reading measure, balanced headings. Regular and light weights
dominate — the brand rarely shouts in bold.

**The eyebrow label:** the brand's most recognizable device — a short label in Work Sans,
uppercase, wide letter-spacing (0.28em), muted stone color. Echoes the spaced `D I V I N E
  A R T S` wordmark. Use above section titles and as kickers.

**Backgrounds:** solid fields — ivory/sand for light, deep navy for the luxe brand
bands — **no gradients** beyond the occasional soft image-protection scrim. The enso
mark sits beautifully on a navy field. Photography, where used, is warm and natural:
stone, gardens, dawn light, the body in stillness; slightly desaturated, gold-lit,
never cold or high-saturation. (No brand photography was available; use tasteful
placeholders and swap in real imagery.)

**Layout:** roomy and vertical, centered reading columns, wide margins. Full-bleed
photographic or solid-color hero bands alternate with narrow prose columns. Alignment
is calm and mostly left/centered; avoid busy multi-column grids.

**Corner radii:** gentle and low — 4–10px on cards and inputs, 6px on buttons. Nothing
is aggressively rounded; containers are never pill-shaped (pills are reserved for tags/
small chips). Squared corners are also acceptable for an austere, print-like feel.

**Borders:** hairline 1px in warm sand/stone tones (`--border-subtle`). Borders are used
more than heavy shadows — the aesthetic is drawn, not floating.

**Shadows:** soft, low, and warm — tinted with ink, never pure black (`--shadow-sm/md`).
Elevation is subtle; most surfaces sit flat on the paper with a hairline instead.

**Transparency & blur:** minimal. An occasional dark scrim over hero imagery for text
legibility; no glassmorphism, no frosted panels.

**Motion:** slow and settling. Ease-out with **no bounce or overshoot**
(`--ease-settle`), durations 140–420ms. Fades and gentle rises; nothing springy or
playful. Motion should feel like exhaling, not popping.

**Hover states:** deepen, don't brighten — accents move to a darker shade
(`--accent-hover`), links gain a fuller underline, cards lift by one soft step. Quiet.

**Press states:** a slight darkening to `--accent-active` and a barely-there settle
(translateY 1px); no dramatic scale.

**Cards:** ivory-raised (`--surface-raised`) on the paper page, a 1px sand border,
low radius (10px), and at most a soft `--shadow-sm`. Restrained, tactile, page-like.

---

## ICONOGRAPHY

The live Google Sites build uses **almost no iconography** — only Google's default gray
social glyphs (Facebook, Instagram, email) in the footer. There is no custom icon set,
no icon font, and **no emoji** anywhere (emoji would contradict the brand's restraint).
The only recurring glyph in copy is the **arrow "→"** used in text CTAs.

**Approach for this system:** icons should be sparse, thin-stroke, and calm — line icons
at ~1.5px stroke, rounded joins, matching the serif's quiet weight. We standardize on
**Lucide** (https://lucide.dev) delivered via CDN as the closest match to the brand's
minimal, natural feel.

> **Substitution flag:** Lucide is a *substitute* — the brand ships no icon set of its
> own. If a specific icon library is preferred, let me know and I'll swap it.

Use icons functionally (navigation, form affordances, small labels), never decoratively
and never in place of words for primary meaning. Prefer the "→" arrow for text CTAs to
stay on-brand. No filled/duotone icons; no colorful icon chips.

---

## VISUAL ASSETS

**Logo:** `assets/logo-enso-navy.png` — a gold enso (Zen brush-circle) enclosing a
refined serif "DIVINE ARTS", on midnight navy (1254×1254, non-transparent). It reads as
a full lockup on a navy field; it is featured in the website hero. For an inline header
on light surfaces, the type-set wordmark (`D I V I N E  A R T S`, see `assets/wordmark.md`)
is used instead, since the mark carries its own navy ground. A transparent/knockout
version for light backgrounds would be a useful addition — request from the client.

**Photography:** none accessible (Google-hosted, token-gated). UI kits use tasteful
placeholder panels; swap in real warm/natural imagery when available.

---

## INDEX / MANIFEST

Root
- `styles.css` — global entry point (consumers link this). @imports only.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skills-compatible entry for downloaded use.
- `thumbnail.html` — project tile.

`tokens/`
- `colors.css` · `typography.css` · `spacing.css` · `effects.css` · `base.css`

`guidelines/` — foundation specimen cards (Design System tab): color, type, spacing,
brand voice, motion, iconography.

`components/`
- `forms/` — **Button, IconButton, Input, Textarea, Checkbox, Radio**
- `content/` — **Card, Badge, Tag, Eyebrow, Blockquote, Accordion**

`ui_kits/`
- `website/` — marketing site recreation: Home, Path, Writing (article), FAQ.

### Intentional additions
- **Eyebrow** — promoted from a CSS utility to a component because the wide-tracked
  label is the brand's single most recognizable visual device.
- **Accordion** — the FAQ page is a long Q&A; an accordion is the natural primitive for it.
- **Blockquote** — the writing is quote-driven ("Different maps, same territory"); a
  pull-quote primitive supports the reading-first brand.

## CAVEATS
- The **brand mark** was provided; the **palette** (gold + midnight navy) is derived
  directly from it. No brand typeface, photography, codebase, or Figma were available —
  only a Google Sites marketing site. Fonts (Spectral + Work Sans), icons (Lucide), and
  all layout are **brand-appropriate interpretations**, not recreations.
- Only a navy-ground logo exists; a transparent/light-background version is needed for
  inline use on ivory surfaces.
- Palette, type, and the whole visual direction are open for concepting — see the note
  to the client below.
