/* @ds-bundle: {"format":4,"namespace":"DivineArtsDesignSystem_fe761d","components":[{"name":"Accordion","sourcePath":"components/content/Accordion.jsx"},{"name":"Badge","sourcePath":"components/content/Badge.jsx"},{"name":"Blockquote","sourcePath":"components/content/Blockquote.jsx"},{"name":"Card","sourcePath":"components/content/Card.jsx"},{"name":"Eyebrow","sourcePath":"components/content/Eyebrow.jsx"},{"name":"Tag","sourcePath":"components/content/Tag.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"IconButton","sourcePath":"components/forms/IconButton.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Radio","sourcePath":"components/forms/Radio.jsx"},{"name":"Textarea","sourcePath":"components/forms/Textarea.jsx"}],"sourceHashes":{"components/content/Accordion.jsx":"b9d6433f2baf","components/content/Badge.jsx":"21b0b07846bd","components/content/Blockquote.jsx":"865a7480aa6e","components/content/Card.jsx":"e713b1b1a52c","components/content/Eyebrow.jsx":"1f7e163b5496","components/content/Tag.jsx":"27262082fa0e","components/forms/Button.jsx":"5e014e73e7c7","components/forms/Checkbox.jsx":"ce8a1f24bed3","components/forms/IconButton.jsx":"04088c836dc4","components/forms/Input.jsx":"025da4741631","components/forms/Radio.jsx":"c65206a763db","components/forms/Textarea.jsx":"f8f887225650","ui_kits/website/App.jsx":"80d21a68f66a","ui_kits/website/Chrome.jsx":"444f1d630e8d","ui_kits/website/FaqScreen.jsx":"eb98ffaffa03","ui_kits/website/HomeScreen.jsx":"91493476da97","ui_kits/website/PathScreen.jsx":"2dca20300af7","ui_kits/website/WritingsScreen.jsx":"4acf9754f727"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DivineArtsDesignSystem_fe761d = window.DivineArtsDesignSystem_fe761d || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/content/Accordion.jsx
try { (() => {
/**
 * Divine Arts — Accordion
 * The FAQ page is a long Q&A; this is its natural primitive. Hairline dividers,
 * serif questions, a quiet rotating chevron, slow settling expand.
 */
function Accordion({
  items = [],
  allowMultiple = false,
  defaultOpen = [],
  style
}) {
  const [open, setOpen] = React.useState(new Set(defaultOpen));
  const toggle = i => {
    setOpen(prev => {
      const next = new Set(allowMultiple ? prev : []);
      if (prev.has(i)) next.delete(i);else next.add(i);
      return next;
    });
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-subtle)",
      ...style
    }
  }, items.map((item, i) => {
    const isOpen = open.has(i);
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      onClick: () => toggle(i),
      "aria-expanded": isOpen,
      style: {
        width: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: "var(--space-4)",
        padding: "var(--space-5) 0",
        background: "none",
        border: "none",
        cursor: "pointer",
        textAlign: "left"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-h4)",
        color: "var(--text-primary)",
        lineHeight: 1.3
      }
    }, item.question), /*#__PURE__*/React.createElement("svg", {
      width: "20",
      height: "20",
      viewBox: "0 0 24 24",
      fill: "none",
      stroke: "var(--accent)",
      strokeWidth: "1.75",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      style: {
        flexShrink: 0,
        transition: "transform var(--dur-base) var(--ease-settle)",
        transform: isOpen ? "rotate(180deg)" : "rotate(0deg)"
      }
    }, /*#__PURE__*/React.createElement("polyline", {
      points: "6 9 12 15 18 9"
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateRows: isOpen ? "1fr" : "0fr",
        transition: "grid-template-rows var(--dur-base) var(--ease-settle)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: "var(--space-6)",
        maxWidth: "var(--measure-prose)",
        fontFamily: "var(--font-body)",
        fontSize: "var(--text-base)",
        lineHeight: "var(--leading-relaxed)",
        color: "var(--text-secondary)"
      }
    }, item.answer))));
  }));
}
Object.assign(__ds_scope, { Accordion });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Accordion.jsx", error: String((e && e.message) || e) }); }

// components/content/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Badge
 * Small status/label chip. Muted, earthen tones; used for course status,
 * "Free", week numbers, and quiet metadata.
 */
function Badge({
  children,
  tone = "neutral",
  style,
  ...rest
}) {
  const tones = {
    neutral: {
      background: "var(--surface-sunken)",
      color: "var(--text-secondary)"
    },
    gold: {
      background: "var(--gold-100)",
      color: "var(--gold-700)"
    },
    navy: {
      background: "var(--navy-100)",
      color: "var(--navy-700)"
    },
    soft: {
      background: "color-mix(in oklch, var(--gold-500) 20%, var(--paper))",
      color: "var(--gold-700)"
    },
    solid: {
      background: "var(--accent)",
      color: "var(--text-on-gold)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--weight-medium)",
      letterSpacing: "0.04em",
      padding: "4px 10px",
      borderRadius: "var(--radius-sm)",
      ...tones[tone],
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Badge.jsx", error: String((e && e.message) || e) }); }

// components/content/Blockquote.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Blockquote / Pull-quote
 * The writing is quote-driven. A serif pull-quote with a clay rule on the left
 * (or centered display variant for hero-scale lines like "Different maps,
 * same territory.").
 */
function Blockquote({
  children,
  cite,
  variant = "side",
  style,
  ...rest
}) {
  if (variant === "display") {
    return /*#__PURE__*/React.createElement("blockquote", _extends({
      style: {
        margin: 0,
        textAlign: "center",
        maxWidth: "22em",
        marginInline: "auto",
        ...style
      }
    }, rest), /*#__PURE__*/React.createElement("p", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-h1)",
        fontWeight: "var(--weight-light)",
        lineHeight: "var(--leading-snug)",
        letterSpacing: "var(--tracking-tight)",
        color: "var(--text-primary)",
        fontStyle: "italic",
        margin: 0
      }
    }, children), cite && /*#__PURE__*/React.createElement("footer", {
      style: {
        marginTop: "var(--space-4)",
        fontFamily: "var(--font-ui)",
        fontSize: "var(--text-sm)",
        letterSpacing: "0.04em",
        color: "var(--text-muted)"
      }
    }, "\u2014 ", cite));
  }
  return /*#__PURE__*/React.createElement("blockquote", _extends({
    style: {
      margin: 0,
      paddingLeft: "var(--space-5)",
      borderLeft: "2px solid var(--accent)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-lead)",
      fontStyle: "italic",
      lineHeight: "var(--leading-normal)",
      color: "var(--text-secondary)",
      margin: 0
    }
  }, children), cite && /*#__PURE__*/React.createElement("footer", {
    style: {
      marginTop: "var(--space-3)",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--text-muted)"
    }
  }, "\u2014 ", cite));
}
Object.assign(__ds_scope, { Blockquote });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Blockquote.jsx", error: String((e && e.message) || e) }); }

// components/content/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Card
 * Parchment-raised surface with a hairline sand border and low radius.
 * Restrained elevation; lifts one soft step on hover when `interactive`.
 */
function Card({
  children,
  variant = "raised",
  interactive = false,
  padding = "lg",
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const pads = {
    none: 0,
    sm: "var(--space-4)",
    md: "var(--space-5)",
    lg: "var(--space-6)"
  };
  const variants = {
    raised: {
      background: "var(--surface-raised)",
      border: "1px solid var(--border-subtle)"
    },
    flat: {
      background: "transparent",
      border: "1px solid var(--border-subtle)"
    },
    sunken: {
      background: "var(--surface-sunken)",
      border: "1px solid transparent"
    },
    ink: {
      background: "var(--surface-ink)",
      border: "1px solid var(--ink-800)",
      color: "var(--text-on-ink)"
    },
    navy: {
      background: "var(--surface-navy)",
      border: "1px solid var(--navy-600)",
      color: "var(--text-on-ink)"
    }
  };
  const hoverStyle = interactive && hover ? {
    boxShadow: "var(--shadow-md)",
    transform: "translateY(-2px)"
  } : {
    boxShadow: variant === "raised" ? "var(--shadow-xs)" : "none"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      borderRadius: "var(--radius-lg)",
      padding: pads[padding],
      cursor: interactive ? "pointer" : "default",
      transition: "box-shadow var(--dur-base) var(--ease-settle), transform var(--dur-base) var(--ease-settle)",
      ...variants[variant],
      ...hoverStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Card.jsx", error: String((e && e.message) || e) }); }

// components/content/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Eyebrow
 * The brand's signature device: a short label in Work Sans, uppercase, wide
 * letter-spacing, muted stone. Echoes the spaced D I V I N E  A R T S wordmark.
 */
function Eyebrow({
  children,
  as = "p",
  color,
  align = "left",
  style,
  ...rest
}) {
  const Tag = as;
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-eyebrow)",
      fontWeight: "var(--weight-medium)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: color || "var(--text-muted)",
      textAlign: align,
      margin: 0,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/content/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Tag
 * Pill-shaped topic/filter chip (writings tags, practice categories).
 * Optional `active` state and dismiss button.
 */
function Tag({
  children,
  active = false,
  onClick,
  onRemove,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const clickable = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "7px",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-regular)",
      padding: "5px 14px",
      borderRadius: "var(--radius-pill)",
      cursor: clickable ? "pointer" : "default",
      border: `1px solid ${active ? "var(--accent)" : "var(--border-strong)"}`,
      background: active ? "var(--accent-soft)" : hover && clickable ? "var(--surface-sunken)" : "transparent",
      color: active ? "var(--gold-700)" : "var(--text-secondary)",
      transition: "background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)",
      ...style
    }
  }, rest), children, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": "Remove",
    onClick: e => {
      e.stopPropagation();
      onRemove(e);
    },
    style: {
      border: "none",
      background: "none",
      cursor: "pointer",
      padding: 0,
      display: "inline-flex",
      color: "inherit",
      opacity: 0.6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.2",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }))));
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/content/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Button
 * Grounded, quiet buttons. Primary is clay-filled; secondary is an ink outline;
 * ghost is text-only; link renders an inline text CTA (pairs with the → arrow).
 */
function Button({
  children,
  variant = "primary",
  size = "md",
  fullWidth = false,
  disabled = false,
  type = "button",
  href,
  onClick,
  style,
  ...rest
}) {
  const sizes = {
    sm: {
      padding: "8px 16px",
      fontSize: "var(--text-sm)"
    },
    md: {
      padding: "12px 24px",
      fontSize: "var(--text-base)"
    },
    lg: {
      padding: "16px 34px",
      fontSize: "var(--text-h4)"
    }
  };
  const base = {
    fontFamily: "var(--font-ui)",
    fontWeight: "var(--weight-medium)",
    lineHeight: 1,
    letterSpacing: "0.01em",
    whiteSpace: "nowrap",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "10px",
    borderRadius: "var(--radius-md)",
    border: "1px solid transparent",
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.5 : 1,
    width: fullWidth ? "100%" : "auto",
    textDecoration: "none",
    transition: "background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard), transform var(--dur-fast) var(--ease-standard)",
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-gold)"
    },
    secondary: {
      background: "transparent",
      color: "var(--text-primary)",
      borderColor: "var(--border-ink)"
    },
    navy: {
      background: "var(--navy-600)",
      color: "var(--text-on-ink)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-primary)"
    },
    link: {
      background: "transparent",
      color: "var(--accent-ink)",
      padding: 0,
      borderRadius: 0,
      letterSpacing: "0.02em"
    }
  };
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const hoverStyle = !disabled && hover ? {
    primary: {
      background: "var(--accent-hover)"
    },
    secondary: {
      background: "var(--ink-900)",
      color: "var(--text-on-ink)"
    },
    navy: {
      background: "var(--navy-700)"
    },
    ghost: {
      background: "var(--surface-sunken)"
    },
    link: {
      color: "var(--accent-hover)"
    }
  }[variant] : {};
  const activeStyle = !disabled && active && variant !== "link" ? {
    transform: "translateY(1px)"
  } : {};
  const Tag = href ? "a" : "button";
  const tagProps = href ? {
    href
  } : {
    type,
    disabled
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({}, tagProps, {
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false),
    style: {
      ...base,
      ...variants[variant],
      ...hoverStyle,
      ...activeStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Divine Arts — Checkbox. Square, hairline, clay when checked. */
function Checkbox({
  label,
  checked,
  defaultChecked,
  onChange,
  disabled,
  id,
  description,
  ...rest
}) {
  const inputId = id || React.useId();
  const [internal, setInternal] = React.useState(defaultChecked || false);
  const isControlled = checked !== undefined;
  const on = isControlled ? checked : internal;
  const toggle = e => {
    if (disabled) return;
    if (!isControlled) setInternal(e.target.checked);
    onChange && onChange(e);
  };
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: "checkbox",
    checked: on,
    onChange: toggle,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flexShrink: 0,
      width: 20,
      height: 20,
      marginTop: 2,
      borderRadius: "var(--radius-xs)",
      border: `1.5px solid ${on ? "var(--accent)" : "var(--border-strong)"}`,
      background: on ? "var(--accent)" : "var(--surface-raised)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "background var(--dur-fast) var(--ease-standard), border-color var(--dur-fast) var(--ease-standard)"
    }
  }, on && /*#__PURE__*/React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text-on-gold)",
    strokeWidth: "3",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, /*#__PURE__*/React.createElement("polyline", {
    points: "20 6 9 17 4 12"
  }))), (label || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-base)",
      color: "var(--text-primary)",
      lineHeight: 1.4
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--text-faint)"
    }
  }, description)));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/forms/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — IconButton
 * A quiet, square-ish button for a single icon (nav toggles, close, controls).
 * Pass a Lucide (or any) SVG/element as children.
 */
function IconButton({
  children,
  label,
  variant = "ghost",
  size = "md",
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const dims = {
    sm: 34,
    md: 42,
    lg: 50
  }[size];
  const [hover, setHover] = React.useState(false);
  const variants = {
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)"
    },
    soft: {
      background: "var(--surface-sunken)",
      color: "var(--text-primary)"
    },
    solid: {
      background: "var(--accent)",
      color: "var(--text-on-gold)"
    }
  };
  const hoverStyle = !disabled && hover ? {
    ghost: {
      background: "var(--surface-sunken)",
      color: "var(--text-primary)"
    },
    soft: {
      background: "var(--sand-200)"
    },
    solid: {
      background: "var(--accent-hover)"
    }
  }[variant] : {};
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onClick: disabled ? undefined : onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: dims,
      height: dims,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: "1px solid transparent",
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1,
      transition: "background var(--dur-fast) var(--ease-standard), color var(--dur-fast) var(--ease-standard)",
      ...variants[variant],
      ...hoverStyle,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Divine Arts — Input
 * A calm text field: parchment-raised, hairline sand border, clay focus.
 * Supports an optional label, hint, and error state.
 */
function Input({
  label,
  hint,
  error,
  id,
  size = "md",
  style,
  ...rest
}) {
  const inputId = id || React.useId();
  const [focus, setFocus] = React.useState(false);
  const pad = {
    sm: "9px 12px",
    md: "12px 15px",
    lg: "15px 18px"
  }[size];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-secondary)"
    }
  }, label), /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-base)",
      color: "var(--text-primary)",
      background: "var(--surface-raised)",
      padding: pad,
      borderRadius: "var(--radius-sm)",
      border: `1px solid ${error ? "var(--danger)" : focus ? "var(--accent)" : "var(--border-strong)"}`,
      boxShadow: focus ? "0 0 0 3px var(--focus-ring)" : "none",
      outline: "none",
      transition: "border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)",
      width: "100%",
      boxSizing: "border-box",
      ...style
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: error ? "var(--danger)" : "var(--text-faint)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Radio.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Divine Arts — Radio. Circular, clay dot when selected. Use within a group. */
function Radio({
  label,
  description,
  checked,
  name,
  value,
  onChange,
  disabled,
  id,
  ...rest
}) {
  const inputId = id || React.useId();
  return /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      display: "flex",
      gap: "12px",
      alignItems: "flex-start",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.5 : 1
    }
  }, /*#__PURE__*/React.createElement("input", _extends({
    id: inputId,
    type: "radio",
    name: name,
    value: value,
    checked: checked,
    onChange: onChange,
    disabled: disabled,
    style: {
      position: "absolute",
      opacity: 0,
      width: 1,
      height: 1
    }
  }, rest)), /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flexShrink: 0,
      width: 20,
      height: 20,
      marginTop: 2,
      borderRadius: "var(--radius-pill)",
      border: `1.5px solid ${checked ? "var(--accent)" : "var(--border-strong)"}`,
      background: "var(--surface-raised)",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      transition: "border-color var(--dur-fast) var(--ease-standard)"
    }
  }, checked && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 10,
      height: 10,
      borderRadius: "var(--radius-pill)",
      background: "var(--accent)"
    }
  })), (label || description) && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "2px"
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-base)",
      color: "var(--text-primary)",
      lineHeight: 1.4
    }
  }, label), description && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--text-faint)"
    }
  }, description)));
}
Object.assign(__ds_scope, { Radio });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Radio.jsx", error: String((e && e.message) || e) }); }

// components/forms/Textarea.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Divine Arts — Textarea. Multi-line companion to Input, same calm styling. */
function Textarea({
  label,
  hint,
  error,
  id,
  rows = 4,
  style,
  ...rest
}) {
  const inputId = id || React.useId();
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%"
    }
  }, label && /*#__PURE__*/React.createElement("label", {
    htmlFor: inputId,
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--weight-medium)",
      color: "var(--text-secondary)"
    }
  }, label), /*#__PURE__*/React.createElement("textarea", _extends({
    id: inputId,
    rows: rows,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-base)",
      lineHeight: "var(--leading-normal)",
      color: "var(--text-primary)",
      background: "var(--surface-raised)",
      padding: "12px 15px",
      borderRadius: "var(--radius-sm)",
      resize: "vertical",
      border: `1px solid ${error ? "var(--danger)" : focus ? "var(--accent)" : "var(--border-strong)"}`,
      boxShadow: focus ? "0 0 0 3px var(--focus-ring)" : "none",
      outline: "none",
      width: "100%",
      boxSizing: "border-box",
      transition: "border-color var(--dur-fast) var(--ease-standard), box-shadow var(--dur-fast) var(--ease-standard)",
      ...style
    }
  }, rest)), (hint || error) && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: error ? "var(--danger)" : "var(--text-faint)"
    }
  }, error || hint));
}
Object.assign(__ds_scope, { Textarea });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Textarea.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/App.jsx
try { (() => {
// Divine Arts — website router
const {
  SiteHeader,
  SiteFooter,
  HomeScreen,
  PathScreen,
  WritingsScreen,
  FaqScreen,
  AboutScreen
} = window;
function App() {
  const [route, setRoute] = React.useState("home");
  const go = r => {
    setRoute(r);
    window.scrollTo({
      top: 0,
      behavior: "instant"
    });
  };
  const Screen = {
    home: HomeScreen,
    path: PathScreen,
    writings: WritingsScreen,
    faq: FaqScreen,
    about: AboutScreen
  }[route] || HomeScreen;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: "100vh",
      display: "flex",
      flexDirection: "column",
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement(SiteHeader, {
    current: route,
    go: go
  }), /*#__PURE__*/React.createElement("main", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement(Screen, {
    go: go
  })), /*#__PURE__*/React.createElement(SiteFooter, {
    go: go
  }));
}
ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Chrome.jsx
try { (() => {
// Divine Arts — shared site chrome (header nav + footer)
const {
  Button
} = window.DivineArtsDesignSystem_fe761d;
const NAV = [{
  key: "home",
  label: "Divine Arts"
}, {
  key: "path",
  label: "Path"
}, {
  key: "writings",
  label: "Writings"
}, {
  key: "faq",
  label: "FAQ"
}, {
  key: "about",
  label: "About"
}];
function Wordmark({
  onClick,
  dark
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      padding: 0,
      display: "inline-flex",
      alignItems: "center",
      gap: "10px"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/enso-mark-gold.png",
    alt: "",
    style: {
      width: 30,
      height: 30
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 500,
      textTransform: "uppercase",
      letterSpacing: "0.34em",
      fontSize: "16px",
      color: dark ? "var(--text-on-ink)" : "var(--text-primary)"
    }
  }, "Divine\xA0Arts"));
}
function SiteHeader({
  current,
  go
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 20,
      background: "rgba(246, 243, 234, 0.88)",
      backdropFilter: "blur(8px)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "0 var(--space-6)",
      height: 72,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, {
    onClick: () => go("home")
  }), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)"
    }
  }, NAV.slice(1).map(n => /*#__PURE__*/React.createElement("button", {
    key: n.key,
    onClick: () => go(n.key),
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      padding: "4px 0",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      fontWeight: 500,
      letterSpacing: "0.02em",
      color: current === n.key ? "var(--accent)" : "var(--text-secondary)",
      borderBottom: current === n.key ? "1.5px solid var(--accent)" : "1.5px solid transparent",
      transition: "color var(--dur-fast) var(--ease-standard)"
    }
  }, n.label)), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: () => go("faq")
  }, "Get Anchored"))));
}
function SiteFooter({
  go
}) {
  const Social = ({
    children,
    label
  }) => /*#__PURE__*/React.createElement("a", {
    href: "#",
    "aria-label": label,
    onClick: e => e.preventDefault(),
    style: {
      width: 38,
      height: 38,
      borderRadius: "var(--radius-pill)",
      border: "none",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--navy-100)",
      background: "rgba(246, 243, 234, 0.12)"
    }
  }, children);
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: "var(--surface-navy)",
      color: "var(--text-on-ink)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-8) var(--space-6)",
      display: "flex",
      flexWrap: "wrap",
      gap: "var(--space-7)",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "26rem"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 500,
      textTransform: "uppercase",
      letterSpacing: "0.34em",
      fontSize: "16px",
      marginBottom: "var(--space-4)"
    }
  }, "Divine\xA0Arts"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-base)",
      lineHeight: 1.7,
      color: "var(--navy-100)",
      margin: 0
    }
  }, "A grounded path of embodiment and awareness. Part of the Ascension Project.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(FooterCol, {
    title: "Explore",
    items: [["Path", "path"], ["Writings", "writings"], ["FAQ", "faq"], ["About", "about"]],
    go: go
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "da-eyebrow",
    style: {
      color: "var(--navy-300)",
      marginBottom: "var(--space-4)"
    }
  }, "Connect"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement(Social, {
    label: "Instagram"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "3",
    width: "18",
    height: "18",
    rx: "5"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "12",
    cy: "12",
    r: "4"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "17.5",
    cy: "6.5",
    r: "1",
    fill: "currentColor",
    stroke: "none"
  }))), /*#__PURE__*/React.createElement(Social, {
    label: "Facebook"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "currentColor"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M14 9h3V6h-3c-1.7 0-3 1.3-3 3v2H8v3h3v6h3v-6h3l1-3h-4V9c0-.6.4-1 1-1z"
  }))), /*#__PURE__*/React.createElement(Social, {
    label: "Email"
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.6"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "3",
    y: "5",
    width: "18",
    height: "14",
    rx: "2"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m3 7 9 6 9-6"
  })))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--navy-300)",
      marginTop: "var(--space-4)"
    }
  }, "practice@divinearts.ca")))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--navy-600)",
      padding: "var(--space-4) var(--space-6)",
      textAlign: "center",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: "var(--navy-300)"
    }
  }, "\xA9 2026 Divine Arts \xB7 Created by Dominique Arsenault"));
}
function FooterCol({
  title,
  items,
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "da-eyebrow",
    style: {
      color: "var(--navy-300)",
      marginBottom: "var(--space-4)"
    }
  }, title), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-3)"
    }
  }, items.map(([label, key]) => /*#__PURE__*/React.createElement("button", {
    key: key,
    onClick: () => go(key),
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      padding: 0,
      textAlign: "left",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--navy-100)"
    }
  }, label))));
}
Object.assign(window, {
  SiteHeader,
  SiteFooter,
  Wordmark
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/FaqScreen.jsx
try { (() => {
// Divine Arts — FAQ + About + email capture
const {
  Eyebrow,
  Accordion,
  Card,
  Input,
  Checkbox,
  Button,
  Blockquote
} = window.DivineArtsDesignSystem_fe761d;
const FAQ = [{
  question: "What is Divine Arts?",
  answer: "A contemplative training system for developing embodied presence. It is not a meditation app, a stress-reduction program, or a spiritual belief system. The practice trains five capacities — presence, clarity, root, attunement, and will — through four anchors applied across sitting, standing, and walking."
}, {
  question: "What does \u201Cdivine\u201D mean here — is this religious?",
  answer: "No. Divine Arts is not affiliated with any religion and does not require any particular belief. The word points toward what lies beyond ordinary grasping — the depth of reality itself when met directly. It is something you verify through direct experience, not a concept to accept."
}, {
  question: "How is this different from meditation?",
  answer: "The primary distinction is embodiment. Divine Arts works with posture, the center of gravity, relaxation, and movement as primary vehicles for presence — not just the mind. This makes the practice more transferable to daily life, because the body is always present even when the mind is not."
}, {
  question: "How long does it take to feel results?",
  answer: "A genuine shift in presence can be felt within a single session. Deeper changes unfold over months. This is cultivation, not a quick fix — the changes accumulate the way a tree grows, not all at once, and not always visibly."
}, {
  question: "I'm a complete beginner — where do I start?",
  answer: "With sitting. Five minutes, once a day. Sit upright but relaxed, bring awareness to the lower belly, and let the breath come and go naturally. You don't need prior experience, special equipment, or a particular spiritual background."
}];
function FaqScreen() {
  const [email, setEmail] = React.useState("");
  const [joined, setJoined] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6) var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Frequently asked"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-display)",
      fontWeight: "var(--weight-light)",
      margin: "var(--space-3) 0 var(--space-6)"
    }
  }, "Questions, answered plainly."), /*#__PURE__*/React.createElement(Accordion, {
    defaultOpen: [0],
    items: FAQ
  })), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-navy)",
      color: "var(--text-on-ink)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-narrow)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "var(--navy-300)",
    align: "center"
  }, "Get Anchored"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      color: "var(--text-on-ink)",
      margin: "var(--space-3) 0 var(--space-4)"
    }
  }, "A free guide + 5-minute practice."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      color: "var(--navy-100)",
      marginBottom: "var(--space-6)"
    }
  }, "Join the list and receive occasional writings on practice. No hype, no urgency."), joined ? /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    style: {
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h4)",
      marginBottom: "var(--space-2)"
    }
  }, "You're on the list."), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-base)",
      color: "var(--text-secondary)"
    }
  }, "Check your inbox for the Get Anchored guide. The practice unfolds from there.")) : /*#__PURE__*/React.createElement("form", {
    onSubmit: e => {
      e.preventDefault();
      if (email) setJoined(true);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "var(--space-4)",
      textAlign: "left"
    }
  }, /*#__PURE__*/React.createElement(Input, {
    label: "",
    type: "email",
    placeholder: "you@example.com",
    value: email,
    onChange: e => setEmail(e.target.value),
    "aria-label": "Email"
  }), /*#__PURE__*/React.createElement(Checkbox, {
    defaultChecked: true,
    label: "Send me occasional writings on practice."
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    type: "submit",
    fullWidth: true
  }, "Get Anchored \u2192")))));
}
function AboutScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("article", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "About"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-h1)",
      fontWeight: "var(--weight-regular)",
      margin: "var(--space-3) 0 var(--space-5)"
    }
  }, "Part of the Ascension Project."), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      lineHeight: "var(--leading-relaxed)",
      color: "var(--text-primary)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lead)",
      color: "var(--text-secondary)"
    }
  }, "Divine Arts is an exploration of how individuals and communities can build a more livable future, one grounded step at a time."), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h3)",
      marginTop: "var(--space-6)"
    }
  }, "About the founder"), /*#__PURE__*/React.createElement("p", null, "My name is Dominique. I grew up around forests, gardens, family, and simple things. From an early age I was drawn to training: martial arts, running, anything that demanded discipline and pushed against limitation."), /*#__PURE__*/React.createElement("p", null, "I eventually became a transportation engineer. I liked understanding systems: what holds things together, what makes them work, where they fail. Alongside that career, another question kept pulling at me: what is actually real?"), /*#__PURE__*/React.createElement(Blockquote, {
    variant: "side"
  }, "Presence was no longer an abstract idea. It was something lived physically and directly."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)"
    }
  }, "From that point forward, three principles became central to my practice: posture, breath, and relaxation. Divine Arts emerged from that process \u2014 a practice rooted in embodiment, awareness, structure, breath, and honest training.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: () => go("path")
  }, "Explore the Path")));
}
Object.assign(window, {
  FaqScreen,
  AboutScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/FaqScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/HomeScreen.jsx
try { (() => {
// Divine Arts — Home screen
const {
  Button,
  Eyebrow,
  Card,
  Badge
} = window.DivineArtsDesignSystem_fe761d;
const CAPACITIES = [["Presence", "Full contact with what is, without needing to move or react."], ["Clarity", "Seeing what is actually here, before the story about it."], ["Root", "Rooted power and stability — weight sinking, structure holding."], ["Attunement", "Sensitivity to the body, others, and the moment."], ["Will", "The capacity to return, again and again, without strain."]];
function HomeScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-navy)",
      color: "var(--text-on-ink)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-10) var(--space-6)",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-enso-navy.png",
    alt: "Divine Arts",
    style: {
      width: 200,
      height: 200,
      display: "block",
      margin: "0 auto var(--space-5)",
      borderRadius: "50%"
    }
  }), /*#__PURE__*/React.createElement(Eyebrow, {
    color: "var(--gold-400)",
    align: "center"
  }, "Presence \xB7 Clarity \xB7 Grounding"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-hero)",
      fontWeight: "var(--weight-light)",
      lineHeight: 1.08,
      margin: "var(--space-5) auto var(--space-5)",
      maxWidth: "16em",
      color: "var(--text-on-ink)"
    }
  }, "A grounded path of embodiment and awareness."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-lead)",
      lineHeight: 1.6,
      color: "var(--navy-100)",
      maxWidth: "34rem",
      margin: "0 auto var(--space-7)"
    }
  }, "Divine Arts is a system of practice exploring presence through posture, breath, movement, relaxation, and direct experience."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-4)",
      justifyContent: "center",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("path")
  }, "Explore the Path"), /*#__PURE__*/React.createElement(Button, {
    variant: "secondary",
    size: "lg",
    onClick: () => go("faq"),
    style: {
      color: "var(--text-on-ink)",
      borderColor: "var(--navy-300)"
    }
  }, "Get Anchored")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: "var(--navy-300)",
      marginTop: "var(--space-4)",
      letterSpacing: "0.08em"
    }
  }, "FREE GUIDE + 5-MINUTE PRACTICE"))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: "center",
      marginBottom: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    align: "center"
  }, "The five capacities"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      marginTop: "var(--space-3)"
    }
  }, "What the practice trains")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))",
      gap: "var(--space-5)"
    }
  }, CAPACITIES.map(([t, d], i) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    variant: "raised"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: "var(--accent)",
      fontWeight: 600,
      letterSpacing: "0.1em",
      marginBottom: "var(--space-3)"
    }
  }, "0", i + 1), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h4)",
      marginBottom: "var(--space-2)"
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-base)",
      lineHeight: 1.6,
      color: "var(--text-secondary)"
    }
  }, d))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-sunken)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)",
      display: "grid",
      gridTemplateColumns: "1.1fr 1fr",
      gap: "var(--space-8)",
      alignItems: "center"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "For those wishing to go deeper"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      margin: "var(--space-3) 0 var(--space-4)"
    }
  }, "Courses, manuals, and writings."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-body)",
      lineHeight: 1.7,
      color: "var(--text-secondary)",
      maxWidth: "34rem"
    }
  }, "Explore a growing collection developed through years of inquiry, training, and direct experience. Everything is practice-first \u2014 training, not studying."), /*#__PURE__*/React.createElement(Button, {
    variant: "navy",
    onClick: () => go("path")
  }, "Browse our Works")), /*#__PURE__*/React.createElement(Card, {
    variant: "raised",
    padding: "lg",
    interactive: true,
    onClick: () => go("faq")
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "flex-start",
      marginBottom: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Flagship course"), /*#__PURE__*/React.createElement(Badge, {
    tone: "gold"
  }, "6 weeks")), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h2)",
      marginBottom: "var(--space-3)"
    }
  }, "Foundations of Presence"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-base)",
      lineHeight: 1.7,
      color: "var(--text-secondary)",
      marginBottom: "var(--space-5)"
    }
  }, "A systematic training in the four anchors \u2014 posture, relaxation, breath, and attention \u2014 across sitting, standing, and walking."), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-lead)",
      color: "var(--accent)"
    }
  }, "Enroll here \u2192")))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontStyle: "italic",
      fontSize: "var(--text-lead)",
      lineHeight: 1.6,
      color: "var(--text-secondary)"
    }
  }, "Divine Arts was created by Dominique Arsenault through more than a decade of contemplative practice, martial training, inquiry, and embodied experimentation."), /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    onClick: () => go("about")
  }, "Read more \u2192")));
}
Object.assign(window, {
  HomeScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/HomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/PathScreen.jsx
try { (() => {
// Divine Arts — Path screen (the four anchors + three practices)
const {
  Eyebrow,
  Card,
  Badge,
  Button,
  Blockquote
} = window.DivineArtsDesignSystem_fe761d;
const ANCHORS = [["Posture", "Grounds and aligns — the spine lengthened, weight sinking, the whole vertical axis organized."], ["Relaxation", "Opens — releasing unnecessary tension so energy can settle and flow."], ["Breath", "Connects — following the natural rhythm of the body, deepening into the belly."], ["Attention", "Engages — resting awareness in the lower belly, the body's center of gravity."]];
const PRACTICES = [["Sitting", "Stillness", "The capacity to be fully present without needing to move or react — the closest contact with deep stillness."], ["Standing", "Structure", "Tests structure under gravity and time, building rooted power and energetic awareness."], ["Walking", "Transition", "Bridges formal practice and daily life — carrying presence through motion and transition."]];
function PathScreen({
  go
}) {
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-ink)",
      color: "var(--text-on-ink)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    color: "var(--stone-400)"
  }, "The Path"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-display)",
      fontWeight: "var(--weight-light)",
      color: "var(--text-on-ink)",
      margin: "var(--space-4) 0",
      maxWidth: "16em"
    }
  }, "Four anchors. Three practices. One center."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-lead)",
      lineHeight: 1.6,
      color: "var(--stone-300)",
      maxWidth: "34rem"
    }
  }, "The practical foundation of every session. When the four anchors converge, the system stabilizes \u2014 and the practice becomes real."))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "The four anchors"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      margin: "var(--space-3) 0 var(--space-6)"
    }
  }, "Posture \xB7 Relaxation \xB7 Breath \xB7 Attention"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))",
      gap: "var(--space-4)"
    }
  }, ANCHORS.map(([t, d], i) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    variant: "flat"
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, "0", i + 1), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      margin: "var(--space-3) 0 var(--space-2)"
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-base)",
      lineHeight: 1.6,
      color: "var(--text-secondary)"
    }
  }, d))))), /*#__PURE__*/React.createElement("section", {
    style: {
      background: "var(--surface-sunken)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Blockquote, {
    variant: "display",
    cite: "On the lower dantien"
  }, "Two to three finger-widths below the navel. The body has learned where home is."))), /*#__PURE__*/React.createElement("section", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "The three core practices"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: "var(--text-h1)",
      margin: "var(--space-3) 0 var(--space-6)"
    }
  }, "Sitting \xB7 Standing \xB7 Walking"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
      gap: "var(--space-5)"
    }
  }, PRACTICES.map(([t, kicker, d]) => /*#__PURE__*/React.createElement(Card, {
    key: t,
    variant: "raised",
    interactive: true
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: 140,
      borderRadius: "var(--radius-md)",
      marginBottom: "var(--space-5)",
      background: "var(--surface-navy)",
      display: "flex",
      alignItems: "flex-end",
      padding: "var(--space-4)",
      color: "var(--navy-100)",
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      letterSpacing: "0.16em",
      textTransform: "uppercase"
    }
  }, kicker), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      marginBottom: "var(--space-2)"
    }
  }, t), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-base)",
      lineHeight: 1.6,
      color: "var(--text-secondary)"
    }
  }, d)))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-7)",
      textAlign: "center"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-lead)",
      color: "var(--text-secondary)",
      marginBottom: "var(--space-5)"
    }
  }, "Five minutes done consistently is worth more than an hour done occasionally."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: () => go("faq")
  }, "Start with Foundations of Presence"))));
}
Object.assign(window, {
  PathScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/PathScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/WritingsScreen.jsx
try { (() => {
// Divine Arts — Writings index + Article reader
const {
  Eyebrow,
  Card,
  Tag,
  Blockquote,
  Button
} = window.DivineArtsDesignSystem_fe761d;
const TAGS = ["All", "Presence", "Breath", "Attention", "Practice"];
const POSTS = [{
  title: "Where You Put Your Attention Is Where You Live",
  date: "15 May 2026",
  tag: "Attention",
  excerpt: "The body has a center of gravity. So does awareness. Most people spend their lives in their heads — not metaphorically, literally."
}, {
  title: "Force Is Not Depth",
  date: "2 Apr 2026",
  tag: "Practice",
  excerpt: "I pushed too hard at times, confused force with depth, and learned that real transformation cannot be manufactured through strain."
}, {
  title: "Different Maps, Same Territory",
  date: "18 Mar 2026",
  tag: "Presence",
  excerpt: "Hara. Lower dantien. The Belt of Truth. Different traditions have named the same place — and pointed at the same practice."
}];
function WritingsScreen({
  go
}) {
  const [active, setActive] = React.useState("All");
  const [open, setOpen] = React.useState(null);
  const list = active === "All" ? POSTS : POSTS.filter(p => p.tag === active);
  if (open) return /*#__PURE__*/React.createElement(Article, {
    post: open,
    back: () => setOpen(null),
    go: go
  });
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--measure-wide)",
      margin: "0 auto",
      padding: "var(--space-9) var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "Writings"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-display)",
      fontWeight: "var(--weight-light)",
      margin: "var(--space-3) 0 var(--space-6)"
    }
  }, "Notes on practice."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-2)",
      flexWrap: "wrap",
      marginBottom: "var(--space-7)"
    }
  }, TAGS.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    active: active === t,
    onClick: () => setActive(t)
  }, t))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))",
      gap: "var(--space-5)"
    }
  }, list.map(p => /*#__PURE__*/React.createElement(Card, {
    key: p.title,
    variant: "raised",
    interactive: true,
    onClick: () => setOpen(p)
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      marginBottom: "var(--space-4)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "da-eyebrow"
  }, p.tag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-xs)",
      color: "var(--text-faint)"
    }
  }, p.date)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      marginBottom: "var(--space-3)",
      lineHeight: 1.25
    }
  }, p.title), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: "var(--text-base)",
      lineHeight: 1.65,
      color: "var(--text-secondary)"
    }
  }, p.excerpt), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-4)",
      fontFamily: "var(--font-body)",
      color: "var(--accent)",
      fontSize: "var(--text-base)"
    }
  }, "Read \u2192")))));
}
function Article({
  post,
  back
}) {
  return /*#__PURE__*/React.createElement("article", {
    style: {
      maxWidth: "var(--measure-prose)",
      margin: "0 auto",
      padding: "var(--space-8) var(--space-6) var(--space-9)"
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "link",
    onClick: back
  }, "\u2190 All writings"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-6)"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, post.tag), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-h1)",
      fontWeight: "var(--weight-regular)",
      margin: "var(--space-3) 0 var(--space-4)",
      lineHeight: 1.15
    }
  }, post.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-sm)",
      color: "var(--text-faint)",
      margin: 0
    }
  }, post.date)), /*#__PURE__*/React.createElement("hr", {
    style: {
      border: "none",
      borderTop: "1px solid var(--border-subtle)",
      margin: "var(--space-6) 0"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-body)",
      fontSize: "var(--text-body)",
      lineHeight: "var(--leading-relaxed)",
      color: "var(--text-primary)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-lead)",
      color: "var(--text-secondary)"
    }
  }, "The body has a center of gravity. So does awareness."), /*#__PURE__*/React.createElement("p", null, "Most people spend their lives in their heads. Not metaphorically \u2014 literally. Awareness pulled upward, behind the eyes, caught in the current of thought. Planning, replaying, narrating."), /*#__PURE__*/React.createElement("p", null, "There is a place in the body that most traditions have known about for a long time. Two to three finger-widths below the navel. The lower belly. Physically, this is your center of gravity \u2014 the point around which your body naturally organizes its weight and movement."), /*#__PURE__*/React.createElement(Blockquote, {
    variant: "side"
  }, "When awareness drops into the lower belly, breathing tends to deepen on its own. The center holds."), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: "var(--space-6)"
    }
  }, "You don't need a technique to begin. You need a direction. Bring your attention to the lower belly. Let the breath come and go on its own. Stay for a few minutes. That's the beginning of the whole thing.")), /*#__PURE__*/React.createElement(Card, {
    variant: "sunken",
    style: {
      marginTop: "var(--space-7)"
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: "0 0 var(--space-4)",
      fontSize: "var(--text-base)",
      color: "var(--text-secondary)"
    }
  }, "If this resonates, ", /*#__PURE__*/React.createElement("em", null, "Foundations of Presence"), " is a six-week training built around exactly this."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary"
  }, "Learn more \u2192")));
}
Object.assign(window, {
  WritingsScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/WritingsScreen.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Accordion = __ds_scope.Accordion;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Blockquote = __ds_scope.Blockquote;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Radio = __ds_scope.Radio;

__ds_ns.Textarea = __ds_scope.Textarea;

})();
